<?php

// Heading
$_['heading_title']    = 'Main page catalog';