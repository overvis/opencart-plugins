<?php

// Heading
$_['heading_title']    = 'Main page catalog';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified Main page catalog module!';
$_['text_edit']        = 'Edit Main page catalog module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Main page catalog module!';