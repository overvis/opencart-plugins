<?php

// Heading
$_['heading_title'] = 'Catalog display';