<?php

// Heading
$_['heading_title']              = 'Simple navigation bar';

// Content
$_['toggle_navigation']          = 'Toggle navigation';
$_['all_categories_button_text'] = 'All product categories';