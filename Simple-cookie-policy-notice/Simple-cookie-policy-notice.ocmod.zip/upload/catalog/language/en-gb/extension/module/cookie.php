<?php

// Heading
$_['heading_title']  = 'Simple cookie policy notice';

// Content
$_['consent_text']   = 'By continuing your visit to this site, you accept the use of cookies';
$_['consent_button'] = 'Got it';