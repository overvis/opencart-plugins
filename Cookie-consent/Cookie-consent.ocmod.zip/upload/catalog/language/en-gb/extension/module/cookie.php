<?php

// Heading
$_['heading_title'] = 'Cookie consent';

// Content
$_['consent_text'] = 'By continuing your visit to this site, you accept the use of cookies';
$_['consent_button'] = 'Got it';