<?php

// Heading
$_['heading_title']    = 'Insert arbitrary html';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified Insert arbitrary html module!';
$_['text_edit']        = 'Edit Insert arbitrary html module';

// Entry
$_['entry_status']     = 'Status';
$_['entry_name']       = 'Module Name';
$_['entry_html']       = 'Html';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Insert arbitrary html module!';
$_['error_name']       = 'Module Name must be between 3 and 64 characters!';
$_['error_html']       = 'Html required!';