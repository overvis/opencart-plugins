<?php

// Heading
$_['heading_title'] = 'Navigation';

// Content
$_['all_categories_button_text'] = 'All product categories';